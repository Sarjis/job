<?php $__env->startSection('body'); ?>
    <div id="page-wrapper">
        <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr class="bg-primary">
                    <th>SL No.</th>
                    <th>Job Title</th>
                    <th>Action</th>

                </tr>
                </thead>
                <tbody>
                <?php ($i=1); ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($post->Job_title); ?></td>
                        <td>
                            <a href="<?php echo e(route('post.show',['post'=>$post->id])); ?>">Details</a>
                        </td>

                        
                        

                        

                            
                                
                            
                            
                                
                                    
                                
                            
                                
                                    
                                
                            
                            
                                
                            
                            
                               
                                
                            
                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job_site\job_site\resources\views/admin/post/create.blade.php ENDPATH**/ ?>