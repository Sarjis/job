<?php $__env->startSection('body'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isApplicant')): ?>
        <div class="content-wrapper">
            <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">

                    <tr>
                        <td>
                            <img src="<?php echo e(asset($profile->image)); ?>" width="100" height="100">
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <?php if($profile->user): ?>
                                <?php echo e($profile->user->first_name); ?> <?php echo e($profile->user->last_name); ?>

                            <?php endif; ?>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <?php if($profile->user): ?>
                                <?php echo e($profile->user->email); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><?php echo e($profile->skills); ?></td>
                    </tr>
                    <tr>
                        <td>
                            <a href="<?php echo e(asset($profile->resume)); ?>">Download CV</a>
                        </td>
                    </tr>

                </table>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/profile/show.blade.php ENDPATH**/ ?>