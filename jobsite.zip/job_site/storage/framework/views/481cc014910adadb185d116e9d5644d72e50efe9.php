<?php $__env->startSection('body'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isApplicant')): ?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>

                        
                            <div class="panel-body">

                                <form accept-charset="UTF-8"
                                      action="<?php echo e(route('profile.update',['profile'=>$profile->id])); ?>" method="post"
                                      class="form-horizontal" enctype="multipart/form-data">
                                    <?php echo method_field("PATCH"); ?>
                                    <?php echo e(csrf_field()); ?>

                                    
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Profile Picture</label>
                                        <div class="col-md-9">
                                            <input type="file" name="image" accept="image/*"/>
                                            <img src="<?php echo e(asset($profile->image)); ?>" width="150" height="200">


                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-md-3">Resume</label>
                                        <div class="col-md-9">
                                            <input class="form-control" type="file" name="resume"
                                                   accept="application/pdf"/>
                                            <?php if(asset($profile->resume)): ?>
                                                <h6>You have already uploaded cv</h6>

                                            <?php else: ?>
                                                <h6>Please uploaded cv</h6>
                                            <?php endif; ?>
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="control-label col-md-3">Skills</label>
                                        <div class="col-md-9">
                                            <textarea name="skills" class="form-control"></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-md-3">Applicant Name</label>
                                        <div class="col-md-9">
                                            <?php if($profile->user): ?>
                                                <?php echo e($profile->user->first_name); ?>

                                            <?php endif; ?>
                                            <select name="user_id" class="form-control form-control <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">

                                                <option>Select Correct Name</option>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-9 col-md-offset-3">
                                            <input type="submit" name="btn" value="Update Profile Info"
                                                   class="btn btn-success"/>
                                        </div>
                                    </div>
                                    <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>


                                </form>
                            </div>
                        
                            
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/profile/edit.blade.php ENDPATH**/ ?>