<nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
            data-accordion="false">



            <li class="nav-item has-treeview">
                <a href="#" class="nav-link">
                    <p>
                        Registration

                    </p>
                </a>
                <ul class="nav nav-treeview">



                    <?php if(!(\Illuminate\Support\Facades\Auth::user())): ?>

                        <li class="nav-item">
                            <router-link :to="{path:'/register-user'}" class="nav-link">
                                <i class="nav-icon fa fa-circle-o text-danger"></i>
                                <p class="text">Registration Form</p>
                            </router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{path:'/login-form'}" class="nav-link">
                                <i class="nav-icon fa fa-circle-o text-danger"></i>
                                <p class="text">Login Form</p>
                            </router-link>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                  style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    <?php endif; ?>


                </ul>

            </li>

        </ul>

    </nav>

</nav>



    
        
        
        
        
    
    




    
        
            
        
        
            
                
                    
                        
                        
                                        
                                    
                    
                    
                
            
            
            
                
                    
                        
                        
                                        
                                    
                    
                    
                
            
            
            
                
                    
                        
                        
                                        
                                    
                    
                    
                
            
            
            
                
                    
                    
                
            
        
        
    
    
    
        
            
        
        
            
                
                    
                        
                            
                            
                        
                        
                            
                                
                            
                        
                    
                
            
            
            
                
                    
                        
                            
                            
                        
                        
                            
                                
                            
                        
                    
                
            
            
            
                
                    
                        
                            
                            
                        
                        
                            
                                
                            
                        
                    
                
            
            
            
                
                    
                        
                            
                            
                        
                        
                            
                                
                            
                        
                    
                
            
            
            
                
                    
                    
                
            
        
        
    
    
    
        
            
        
        
            
                
                    
                        
                        
                    
                
            
            
            
                
                    
                        
                        
                    
                
            
            
            
                
                    
                        
                        
                    
                
            
            
            
                
                    
                        
                        
                    
                
            
            
            
                
                    
                        
                        
                    
                
            
            
            
                
                    
                    
                
            
        
        
    
    
    
        
            
        
        
            
            
            
            
            
            
            
        
        
    
    
<?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/admin/includes/nav.blade.php ENDPATH**/ ?>