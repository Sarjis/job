<?php $__env->startSection('body'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isApplicant')): ?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>

                        <div class="panel-body">
                            <form action="<?php echo e(route('profile.store')); ?>" method="POST" class="form-horizontal"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Profile Picture</label>
                                    <div class="col-md-9">
                                        <input type="file" name="image" accept="image/*"/>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Resume</label>
                                    <div class="col-md-9">
                                        <input type="file" name="resume" accept="application/pdf"/>

                                    </div>
                                </div>


                                <div class="form-group">
                                    <label class="control-label col-md-3">Skills</label>
                                    <div class="col-md-9">
                                        <textarea name="skills" class="form-control"></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Applicant Name</label>
                                    <div class="col-md-9">

                                        <?php if($applicants ): ?>
                                            <select name="user_id" class="form-control">
                                                <option>Select your Name</option>
                                                <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($applicant->id); ?>"><?php echo e($applicant->first_name); ?> <?php echo e($applicant->last_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php else: ?>
                                            <h1>something wrong</h1>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-9 col-md-offset-3">
                                        <input type="submit" name="btn" value="Save Profile Info"
                                               class="btn btn-success"/>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/profile/index.blade.php ENDPATH**/ ?>