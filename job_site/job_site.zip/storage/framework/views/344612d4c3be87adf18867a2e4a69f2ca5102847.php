<?php $__env->startSection('body'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isCompany')): ?>
    <div class="content-wrapper">
        <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                <tr class="bg-primary">
                    <th>SL</th>
                    <th>Name</th>
                    <th>Email</th>


                </tr>
                </thead>
                <tbody>
                <?php ($i=0); ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td>
                            <?php if($post->applicant): ?>
                                <?php echo e($post->applicant->first_name); ?> <?php echo e($post->applicant->last_name); ?>

                            <?php endif; ?>
                        </td>
                        <td>  <?php if($post->applicant): ?>
                                <?php echo e($post->applicant->email); ?>

                            <?php endif; ?>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/admin/post/applicant-post.blade.php ENDPATH**/ ?>