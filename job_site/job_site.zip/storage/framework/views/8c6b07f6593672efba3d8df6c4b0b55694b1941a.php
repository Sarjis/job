<?php $__env->startSection('body'); ?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="panel panel-default">
                        <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>
                        <div class="panel-body">
                            <form action="" method="POST" class="form-horizontal">

                                <div class="form-group">
                                    <label class="control-label col-md-3">Job Title</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($post->Job_title); ?>" name="job_title"
                                               class="form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Job Description</label>
                                    <div class="col-md-9">
                                        <textarea class="form-control"> <?php echo e($post->Job_description); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3">Salary</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($post->salary); ?>" name="salary"
                                               class="form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Location</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($post->location); ?>" name="location"
                                               class="form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Country</label>
                                    <div class="col-md-9">
                                        <input type="text" value="<?php echo e($post->country); ?>" name="country"
                                               class="form-control"/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3">Company Name</label>
                                    <div class="col-md-9">
                                        <?php if($post->user): ?>
                                            <input type="text" name="country" value="<?php echo e($post->user->business_name); ?>"
                                                   class="form-control"/>
                                        <?php endif; ?>


                                    </div>
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isApplicant')): ?>

                                    <div class="form-group">
                                        <div class="col-md-9 col-md-offset-3">
                                            
                                            <a href="<?php echo e(route('application/select',['id'=>$post->id])); ?>" name="btn" class="btn btn-success">Apply </a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/admin/post/show.blade.php ENDPATH**/ ?>