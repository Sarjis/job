<?php $__env->startSection('body'); ?>

        <div class="content-wrapper">
            <h3 class="text-center text-success"> <?php echo e(Session::get('message')); ?></h3>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr class="bg-primary">
                        <th>SL No.</th>
                        <th>Skills</th>
                        <th>CV</th>
                        <th>Email</th>
                        <th>Image</th>
                        <th>Action</th>


                    </tr>
                    </thead>
                    <tbody>
                    <?php ($i=1); ?>
                    <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($profile->skills); ?></td>

                            <td>
                                <a href="<?php echo e(asset($profile->resume)); ?>">Download CV</a>

                            </td>
                            <td>
                                <?php if($profile->user): ?>
                                    <?php echo e($profile->user->email); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <img src="<?php echo e(asset($profile->image)); ?>" width="50" height="50">
                            </td>

                            <td>
                                <a href="<?php echo e(route('register',['id'=>\Illuminate\Support\Facades\Auth::user()->id,'profile_id'=>$profile->id])); ?>">Select</a>
                            </td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/profile/create.blade.php ENDPATH**/ ?>