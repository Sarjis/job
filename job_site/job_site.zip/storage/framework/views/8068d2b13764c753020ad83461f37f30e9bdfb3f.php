





































<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="info">
                <?php if(Auth::user()): ?>
                    <a href="#"
                       class="d-block"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>"
                       class="d-block">Login</a>
                <?php endif; ?>

            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isCompany')): ?>
                    <li class="nav-item has-treeview">
                        <a class="nav-link" href="<?php echo e(route('profile.create')); ?>">Dashboard</a>
                    </li>
                <?php endif; ?>

                <li class="nav-item has-treeview">
                    <a class="nav-link" href="<?php echo e(route('/posts')); ?>">View All Jobs</a>
                </li>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isCompany')): ?>
                    

                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <p>
                                Company
                                <i class="fa fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('post.index')); ?>" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-danger"></i>
                                    <p class="text">Post Job</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('applicant-post')); ?>" class="nav-link">
                                    <i class="nav-icpost.indexon fa fa-circle-o text-danger"></i>
                                    <p class="text">See Registered Applicant</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isApplicant')): ?>
                    <li class="nav-item has-treeview">
                        <a href="#" class="nav-link">
                            <p>
                                Applicant
                                <i class="fa fa-angle-left right"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.index')); ?>" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-danger"></i>
                                    <p class="text">Create Profile</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.show',['profile'=>\Illuminate\Support\Facades\Auth::user()->id])); ?>" class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-danger"></i>
                                    <p class="text">View Profile</p>
                                </a>
                            </li>
                        </ul>
                        <ul class="nav nav-treeview">

                            <li class="nav-item">
                                <a href="<?php echo e(route('profile.edit',['profile'=>\Illuminate\Support\Facades\Auth::user()->id])); ?>"
                                   class="nav-link">
                                    <i class="nav-icon fa fa-circle-o text-danger"></i>
                                    <p class="text">Update Profile</p>
                                </a>
                            </li>

                        </ul>
                    </li>

                <?php endif; ?>
                
            </ul>

        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH H:\Xampp\htdocs\Git Project\job\job_site\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>